﻿using APIDemo.Models;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Web.Http;

namespace APIDemo.Controllers
{
    public class UpgradeDetailsController : ApiController
    {
        // GET api/<controller>
        public ResultDataCol Get()
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchUpgradeStatusDetails_Result> upgradeStatusDetails = db.sp_FetchUpgradeStatusDetails();
                IEnumerable<object> data = upgradeStatusDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();



                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile)
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchUpgradeStatusDetailsById_Result> upgradeStatusDetails = db.sp_FetchUpgradeStatusDetailsById(mobile);
                IEnumerable<object> data = upgradeStatusDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}