﻿using APIDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIDemo.Controllers
{
    public class TimelineDetailsController : ApiController
    {
        // GET api/<controller>
        public ResultDataCol Get()
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchTimeline_Result> timelineDetails = db.sp_FetchTimeline();
                IEnumerable<object> data = timelineDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}