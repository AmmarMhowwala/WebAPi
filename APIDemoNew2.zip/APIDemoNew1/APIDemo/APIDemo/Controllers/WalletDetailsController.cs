﻿using APIDemo.Models;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Web.Http;

namespace APIDemo.Controllers
{
    public class WalletDetailsController : ApiController
    {
        // GET api/<controller>
        public ResultDataCol Get()
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchWalletDetails_Result> walletDetails = db.sp_FetchWalletDetails();
                IEnumerable<object> data = walletDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }
            
          }

        // GET api/<controller>/5
        public ResultDataCol Get(string mobile)
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchWalletDetailsById_Result> walletDetails = db.sp_FetchWalletDetailsById(mobile);
                IEnumerable<object> data = walletDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}