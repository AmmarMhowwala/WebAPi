﻿using APIDemo.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APIDemo.Controllers
{
    public class MembershipDetailsController : ApiController
    {
        public ResultDataCol Get()
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchMemberShipDetails_Result> memberShipDetails = db.sp_FetchMemberShipDetails();
                IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();



                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile, string serviceType)
        {
            using (computerprideEntities db = new computerprideEntities())
            {
                ObjectResult<sp_FetchMemberShipDetailsById_Result> memberShipDetails = db.sp_FetchMemberShipDetailsById(mobile, serviceType);
                IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.RequestDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }
        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}