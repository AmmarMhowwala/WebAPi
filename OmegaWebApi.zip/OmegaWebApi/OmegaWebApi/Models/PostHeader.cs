﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmegaWebApi.Models
{
    public class PostHeader
    {
        string MobileNo;
        string ServiceType;
        public string serviceType { get; set; }
        public string mobileNo { get; set; }
    }
}