﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OmegaWebApi.Models
{
    public class ResultDataCol
    {
        private string status;
        public string Status { get; set; }
        private string message;
        public string Message { get; set; }
        private IEnumerable<object> resultDetails;
        public IEnumerable<object> ResultDetails { get; set; }
    }
}