﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class UserRefDetailsController : ApiController
    {
        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {

                ObjectResult<sp_FetchUserRefDetails_Result> userRefInfo = db.sp_FetchUserRefDetails();
                IEnumerable<object> data = userRefInfo.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();


                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchUserRefDetailsById_Result> userRefInfo = db.sp_FetchUserRefDetailsById(mobile);
                IEnumerable<object> data = userRefInfo.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        [Route("UserRefDetails/FetchUserRefDetailsByMobile")]
        public ResultDataCol Post([FromBody] PostHeader header)
        {

            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchUserRefDetailsById_Result> userRefInfo = db.sp_FetchUserRefDetailsById(header.mobileNo);
                IEnumerable<object> data = userRefInfo.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }
        [Route("UserRefDetails/FetchUserRefDetails")]
        public ResultDataCol Post()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchUserRefDetails_Result> userRefInfo = db.sp_FetchUserRefDetails();
                IEnumerable<object> data = userRefInfo.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}