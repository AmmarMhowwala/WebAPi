﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class TransferLimitDetailsController : ApiController
    {
        // GET api/<controller>
        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchTransferLimitDetails_Result> transferLimitDetails = db.sp_FetchTransferLimitDetails();
                IEnumerable<object> data = transferLimitDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();



                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        [Route("TransferLimitDetails/FetchTransferLimitDetails")]
        public ResultDataCol Post()
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchTransferLimitDetails_Result> transferLimitDetails = db.sp_FetchTransferLimitDetails();
                    IEnumerable<object> data = transferLimitDetails.Cast<object>().ToList();
                    if (data != null || data.Count() > 0)
                    {
                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }

        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}
