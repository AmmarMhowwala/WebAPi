﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class WalletStatementDetailsController : ApiController
    {
        // GET api/<controller>
        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchWalletStatementDetails_Result> walletStatementDetails = db.sp_FetchWalletStatementDetails();
                IEnumerable<object> data = walletStatementDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }

        }

        // GET api/<controller>/5
        public ResultDataCol Get(string mobile)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchWalletStatementDetailsById_Result> walletStatementDetails = db.sp_FetchWalletStatementDetailsById(mobile);
                IEnumerable<object> data = walletStatementDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }
        }


        [Route("WalletStatementDetails/FetchWalletStatementDetailsByMobile")]
        public ResultDataCol Post([FromBody] PostHeader header)
        {

            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchWalletStatementDetailsById_Result> walletStatementDetails = db.sp_FetchWalletStatementDetailsById(header.mobileNo);
                IEnumerable<object> data = walletStatementDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }
        [Route("WalletStatementDetails/FetchWalletStatementDetails")]
        public ResultDataCol Post()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchWalletStatementDetails_Result> walletStatementDetails = db.sp_FetchWalletStatementDetails();
                IEnumerable<object> data = walletStatementDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }


        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}