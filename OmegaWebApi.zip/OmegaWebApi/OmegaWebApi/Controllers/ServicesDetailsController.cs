﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class ServicesDetailsController : ApiController
    {
        // GET api/<controller>

        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchServiceDetails_Result> serviceDetails = db.sp_FetchServiceDetails();
                IEnumerable<object> data = serviceDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }

        }

        // GET api/<controller>/5
        public ResultDataCol Get(string serviceType)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchServicesDetailsById_Result> serviceDetails = db.sp_FetchServicesDetailsById(serviceType);
                IEnumerable<object> data = serviceDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }
                return result;
            }
        }


        [Route("ServicesDetails/FetchServiceDetails")]
        public ResultDataCol Post()
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
               
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchServiceDetails_Result> serviceDetails = db.sp_FetchServiceDetails();
                    IEnumerable<object> data = serviceDetails.Cast<object>().ToList();
                
               
                    if (data != null || data.Count() > 0)
                    {

                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;

                    }
               
                }
                    return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }

        }


        [Route("ServicesDetails/FetchServiceDetailsByServiceType")]
        public ResultDataCol Post([FromBody] PostHeader header)
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchServicesDetailsById_Result> serviceDetails = db.sp_FetchServicesDetailsById(header.serviceType);
                    IEnumerable<object> data = serviceDetails.Cast<object>().ToList();
                    if (data != null || data.Count() > 0)
                    {
                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
        }
        
        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}