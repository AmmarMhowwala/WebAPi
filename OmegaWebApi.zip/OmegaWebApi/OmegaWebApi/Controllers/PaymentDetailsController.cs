﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class PaymentDetailsController : ApiController
    {
        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchPaymentDetails_Result> paymentDetails = db.sp_FetchPaymentDetails();
                IEnumerable<object> data = paymentDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();



                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile, string serviceType)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchPaymentDetailsById_Result> paymentDetails = db.sp_FetchPaymentDetailsById(mobile, serviceType);
                IEnumerable<object> data = paymentDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        // POST api/<controller>
        [Route("PaymentDetails/InsertPaymentDetails")]
        public ResultDataCol Post([FromBody]PaymentStatu paymentDetails)
        { ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                if (paymentDetails != null)
                {
                    if (ModelState.IsValid)
                    {

                        using (OmegaEntities db = new OmegaEntities())
                        {
                            int count = 0;
                            var id = count != null ?
                            new ObjectParameter("id", count) :
                            new ObjectParameter("id", typeof(int));
                            int res = db.sp_InsertPaymentDetails(paymentDetails.MobileNo, paymentDetails.ServiceType, paymentDetails.ServiceAmt, paymentDetails.PaymentStatus, paymentDetails.PaymentId, paymentDetails.SessionId, DateTime.Now.ToString(), id);
                            result.Status = "1";
                            result.Message = "Success";
                            if (!(Convert.ToInt32(id.Value) > 0))
                            {
                                result.Status = "0";
                                result.Message = "Failure";
                            }                           
                        }
                    }
                }
                return result;
             }
            
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
        }



        [Route("PaymentDetails/FetchPaymentDetails")]
        public ResultDataCol Post()
        {
             ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchPaymentDetails_Result> paymentDetails = db.sp_FetchPaymentDetails();
                    IEnumerable<object> data = paymentDetails.Cast<object>().ToList();         
                   if (data != null || data.Count() > 0)
                    {
                    result.Status = "1";
                    result.Message = "Success";
                    result.ResultDetails = data;

                    }                
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
        }

        [Route("PaymentDetails/FetchPaymentDetailsbyMobileServiceType")]
        public ResultDataCol Post([FromBody] PostHeader header)
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchPaymentDetailsById_Result> paymentDetails = db.sp_FetchPaymentDetailsById(header.mobileNo, header.serviceType);
                    IEnumerable<object> data = paymentDetails.Cast<object>().ToList();
                    if (data != null || data.Count() > 0)
                    {
                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;
                   
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}