﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class MembershipDetailsController : ApiController
    {
        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchMemberShipDetails_Result> memberShipDetails = db.sp_FetchMemberShipDetails();
                IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();
                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile, string serviceType)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchMemberShipDetailsById_Result> memberShipDetails = db.sp_FetchMemberShipDetailsById(mobile, serviceType);
                IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }
        // POST api/<controller>

         [Route("MembershipDetails/FetchMemberShipDetails")]
        public ResultDataCol Post()
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchMemberShipDetails_Result> memberShipDetails = db.sp_FetchMemberShipDetails();
                    IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();
                    if (data != null || data.Count() > 0)
                    {
                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;
                    }
                }
                return result;
            }
             catch(Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
               
            
        }

         [Route("MembershipDetails/FetchMemberShipDetailsByMobileServiceType")]
         public ResultDataCol Post(PostHeader header)
         {
             
             ResultDataCol result = new ResultDataCol();
             result.Status = "0";
             result.Message = "Failure";
             try
             {
                 if (header != null)
                 {
                     using (OmegaEntities db = new OmegaEntities())
                     {
                         ObjectResult<sp_FetchMemberShipDetailsById_Result> memberShipDetails = db.sp_FetchMemberShipDetailsById(header.mobileNo, header.serviceType);
                         IEnumerable<object> data = memberShipDetails.Cast<object>().ToList();


                         if (data != null || data.Count() > 0)
                         {
                             result.Status = "1";
                             result.Message = "Success";
                             result.ResultDetails = data;

                         }

                     }
                 }
                 return result;
             }
             catch(Exception ex)
             {
                 result.Message = "Failure" + ex;
                return result;
             }
                 
             
         }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}