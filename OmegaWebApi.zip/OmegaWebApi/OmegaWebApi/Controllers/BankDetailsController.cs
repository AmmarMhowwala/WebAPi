﻿using OmegaWebApi.Models;
using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace OmegaWebApi.Controllers
{
    public class BankDetailsController : ApiController
    {
        // GET api/values

        public ResultDataCol Get()
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchBankDetails_Result> bankDetails = db.sp_FetchBankDetails();
                IEnumerable<object> data = bankDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();



                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;

                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }

        public ResultDataCol Get(string mobile)
        {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchBankDetailsById_Result> bankDetails = db.sp_FetchBankDetailsById(mobile);
                IEnumerable<object> data = bankDetails.Cast<object>().ToList();
                ResultDataCol result = new ResultDataCol();

                result.Status = "1";
                result.Message = "Success";
                result.ResultDetails = data;
                if (data == null || data.Count() == 0)
                {

                    result.Status = "0";
                    result.Message = "Failure";

                }


                return result;
            }
        }


        [Route("BankDetails/InsertBankDetails")]
        public ResultDataCol Post([FromBody]UserBankInfo userBankInfoDetails)
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                if (userBankInfoDetails != null)
                {
                    if (ModelState.IsValid)
                    {
                        using (OmegaEntities db = new OmegaEntities())
                        {
                            int count = 0;
                            var id = count != null ?
                            new ObjectParameter("id", count) :
                            new ObjectParameter("id", typeof(int));
                            int res = db.sp_InsertUserBankDetails(userBankInfoDetails.UserBankName, userBankInfoDetails.UserAccHolderName, userBankInfoDetails.UserAccNumber, userBankInfoDetails.UserAccType, userBankInfoDetails.UserIFSCCode, userBankInfoDetails.UserMobileNo, userBankInfoDetails.UserPanNo, DateTime.Now.ToString(), id);
                            result.Status = "1";
                            result.Message = "Success";
                            if (!(Convert.ToInt32(id.Value) > 0))
                            {
                                result.Status = "0";
                                result.Message = "Failure";
                            }
                            return result;
                        }
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
            
        }

        [Route("BankDetails/FetchBankDetailsByMobile")]
        public ResultDataCol Post([FromBody] PostHeader header)
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
            using (OmegaEntities db = new OmegaEntities())
            {
                ObjectResult<sp_FetchBankDetailsById_Result> bankDetails = db.sp_FetchBankDetailsById(header.mobileNo);
                IEnumerable<object> data = bankDetails.Cast<object>().ToList();
               
                if (data != null || data.Count() > 0)
                {

                    result.Status = "1";
                    result.Message = "Success";
                    result.ResultDetails = data;

                }
            }
             return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }
        }
        [Route("BankDetails/FetchBankDetails")]
        public ResultDataCol Post()
        {
            ResultDataCol result = new ResultDataCol();
            result.Status = "0";
            result.Message = "Failure";
            try
            {
                using (OmegaEntities db = new OmegaEntities())
                {
                    ObjectResult<sp_FetchBankDetails_Result> bankDetails = db.sp_FetchBankDetails();
                    IEnumerable<object> data = bankDetails.Cast<object>().ToList();
                    if (data != null || data.Count() > 0)
                    {
                        result.Status = "1";
                        result.Message = "Success";
                        result.ResultDetails = data;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                result.Message = "Failure" + ex;
                return result;
            }

        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}